package com.sample;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import java.util.List;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class AnnotationTest {
    private TestUtil util = TestUtil.getInstance();

    @InjectMocks
    private Sample sample;

    @Before
    public void setup() {
        // モックを有効にする
        // MockitoAnnotations.initMocks(this);
    }

    /**
     * 任意の値を返す
     */
    @Test
    public void execute02(){
        Sample sample = mock(Sample.class);
        when(sample.getId()).thenReturn("foo");

        Main m = new MainExt();
        util.setValue(m, "sample", sample);

        Assert.assertEquals("foo", m.getId());
    }

}

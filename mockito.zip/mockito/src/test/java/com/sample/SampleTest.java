package com.sample;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.MockitoAnnotations;

import java.util.List;

import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;

/**
 * http://etc9.hatenablog.com/entry/20101108/1289218176
 * http://etc9.hatenablog.com/entry/20101109/1289304795
 * http://etc9.hatenablog.com/entry/20101110/1289406652
 */
public class SampleTest {
    @Before
    public void setup() {
        // モックを有効にする
        //MockitoAnnotations.initMocks(this);
    }

    /**
     * 値の検証
     */
    @Test
    public void execute01() {
        List<String> list = mock(List.class);
        list.add("first");

        verify(list).add("first");
    }

    /**
     * 任意の値を返す
     */
    @Test
    public void execute02() {
        List<String> list = mock(List.class);
        when(list.get(0)).thenReturn("first");
        when(list.get(1)).thenReturn("second");

        Assert.assertEquals("second", list.get(1));
    }

    /**
     * 例外を発生
     */
    @Test
    public void execute03() {
        List<String> list = mock(List.class);
        when(list.get(0)).thenReturn("first");
        doThrow(new RuntimeException()).when(list).get(1);

        Assert.assertEquals("first", list.get(0));
        try {
            list.get(1);
            fail();
        } catch (RuntimeException e) {
            ;
        }
    }

    /**
     * 複数回のモックメソッド呼び出しの結果を変化させる
     */
    @Test
    public void execute04() {
//        Sample sample = mock(Sample.class);
//        when(sample.getId()).thenReturn("100").thenReturn("200");
//
//        Assert.assertEquals("100", sample.getId());
//        Assert.assertEquals("200", sample.getId());

        Sample sample = new Sample();
        Sample spy = spy(sample);
        when(spy.getId()).thenReturn("100").thenReturn("200");

        Assert.assertEquals("100", spy.getId());
        Assert.assertEquals("200", spy.getId());
    }

    /**
     * 実オブジェクトのメソッドの内、必要とするメソッドだけ動作を変える
     */
    @Test
    public void execute05() {
        Sample sample = new Sample();
        Sample spy = spy(sample);
        when(spy.getId()).thenReturn("100");

        Assert.assertEquals("100", spy.getId());
    }

    /**
     * 実オブジェクトのメソッドの内、必要とするメソッドだけ動作を変える(上記がエラーの場合)
     */
    @Test
    public void execute06() {
        Sample sample = new Sample();
        Sample spy = spy(sample);
        doReturn("100").when(spy).getId();

        Assert.assertEquals("100", spy.getId());
    }
}


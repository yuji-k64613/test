package com.sample;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class TestUtil {
    private static TestUtil ourInstance = new TestUtil();

    public static TestUtil getInstance() {
        return ourInstance;
    }

    private TestUtil() {
    }

    public Object invoke(Class clazz, String methodName, Class[] types, Object obj, Object[] args) {
        Method method = null;
        try {
            while (true) {
                try {
                    method = clazz.getMethod(methodName, types);
                    method.setAccessible(true);
                    return method.invoke(obj, args);
                }
                catch (NoSuchMethodException e){
                    clazz = clazz.getSuperclass();
                    if (clazz == null){
                        throw new RuntimeException();
                    }
                }
            }
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (InvocationTargetException e) {
            throw new RuntimeException(e);
        }
    }

    public void setValue(Object obj, String name, Object value) {
        Class<? extends Object> clazz = obj.getClass();
        try {
            while (true) {
                try {
                    Field f = clazz.getDeclaredField(name);
                    f.setAccessible(true);
                    f.set(obj, value);
                    return;
                }
                catch (NoSuchFieldException e){
                    clazz = clazz.getSuperclass();
                    if (clazz == null){
                        throw new RuntimeException();
                    }
                }
            }
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }

    public Object getValue(Object obj, String name) {
        Class<? extends Object> clazz = obj.getClass();
        try {
            while (true) {
                try {
                    Field f = clazz.getDeclaredField(name);
                    f.setAccessible(true);
                    return f.get(obj);
                }
                catch (NoSuchFieldException e){
                    clazz = clazz.getSuperclass();
                    if (clazz == null){
                        throw new RuntimeException();
                    }
                }
            }
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }
}
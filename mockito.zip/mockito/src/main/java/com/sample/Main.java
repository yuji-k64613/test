package com.sample;

import org.mockito.InjectMocks;

public class Main {
    private Sample sample;

    public String getId(){
        return sample.getId();
    }
}

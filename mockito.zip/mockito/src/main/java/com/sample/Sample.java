package com.sample;

import java.util.ArrayList;
import java.util.List;

public class Sample {
    private String id;

    public int execute() {
        try {
            foo();
            return 0;
        } catch (Exception e) {
            // このケースは無理
            return -1;
        }
    }

    private void foo() throws Exception {

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

}

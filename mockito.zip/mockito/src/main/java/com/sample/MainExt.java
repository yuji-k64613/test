package com.sample;

public class MainExt extends Main {
}
